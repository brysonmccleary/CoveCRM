import { useEffect, useState, useRef } from "react";
import axios from "axios";
import { useNotifStore } from "@/lib/notificationsStore";
import { formatStamp } from "@/lib/format";

interface Lead {
  _id: string;
  "First Name": string;
  Phone: string;
  updatedAt: string;
  interactionHistory: {
    type: "inbound" | "outbound" | "ai" | "system";
    text: string;
    date: string;
  }[];
}

export default function ConversationsPanel() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [reply, setReply] = useState("");
  const [bookingTime, setBookingTime] = useState("");
  const [bookingForMessageIndex, setBookingForMessageIndex] = useState<number | null>(null);
  const chatRef = useRef<HTMLDivElement>(null);

  // 🔔 unread store
  const unreadByLead = useNotifStore((s) => s.unreadByLead);
  const clearUnread = useNotifStore((s) => s.clear);

  useEffect(() => {
    loadLeads();
  }, []);

  const loadLeads = async () => {
    const res = await axios.get("/api/leads/messages");
    setLeads(res.data.leads || []);
  };

  const handleReply = async () => {
    if (!selectedLead || !reply) return;

    await axios.post("/api/twilio/send-sms", {
      to: selectedLead.Phone,
      from: selectedLead.Phone, // backend decides actual sender
      body: reply,
      leadId: selectedLead._id,
    });

    setReply("");
    await loadLeads();
    setSelectedLead((prev) => (prev ? leads.find((l) => l._id === prev._id) || prev : null));
  };

  const handleBookClick = (idx: number) => setBookingForMessageIndex(idx);

  const handleConfirmBooking = async () => {
    if (!selectedLead || !bookingTime || bookingForMessageIndex === null) return;

    try {
      const res = await axios.post("/api/calendar/create-event", {
        leadId: selectedLead._id,
        time: bookingTime,
        phone: selectedLead.Phone,
        name: selectedLead["First Name"],
      });

      if (res.status === 200) {
        alert("✅ Appointment booked");
        setBookingTime("");
        setBookingForMessageIndex(null);
      } else {
        alert("❌ Booking failed");
      }
    } catch (err: any) {
      console.error("❌ Booking failed", err);
      const msg = err?.response?.data?.message || "❌ Booking failed";
      alert(msg);
    }
  };

  // auto-scroll to bottom when thread changes
  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [selectedLead?.interactionHistory?.length]);

  // 🔔 clear unread when a thread opens
  useEffect(() => {
    if (selectedLead?._id) clearUnread(selectedLead._id);
  }, [selectedLead?._id, clearUnread]);

  return (
    <div className="flex flex-col md:flex-row gap-4 p-4">
      {/* Sidebar */}
      <div className="w-full md:w-1/3 border rounded p-3 h-[80vh] overflow-y-auto">
        <h3 className="font-semibold text-lg mb-3">Conversations</h3>
        {leads.map((lead) => {
          const lastMsg = lead.interactionHistory?.slice(-1)[0];
          const listTime = lastMsg?.date || lead.updatedAt;
          const unreadCount = unreadByLead?.[lead._id] || 0;

          return (
            <div
              key={lead._id}
              className={`relative border p-2 rounded mb-2 cursor-pointer ${
                selectedLead?._id === lead._id ? "bg-blue-100" : "hover:bg-gray-50"
              }`}
              onClick={() => {
                setSelectedLead(lead);
                if (unreadCount > 0) clearUnread(lead._id);
              }}
            >
              {/* numeric badge */}
              {unreadCount > 0 && (
                <span className="absolute right-2 top-2 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-pink-500 px-1 text-xs font-semibold text-white">
                  {unreadCount}
                </span>
              )}

              <p className="font-bold pr-6">{lead["First Name"]}</p>
              <p className="text-sm text-gray-600 truncate">{lastMsg?.text}</p>
              <p className="text-xs text-gray-400">{formatStamp(listTime)}</p>
            </div>
          );
        })}
      </div>

      {/* Chat Window */}
      <div className="w-full md:w-2/3 border rounded p-3 flex flex-col h-[80vh]">
        {selectedLead ? (
          <>
            <h3 className="font-semibold text-lg mb-2">
              {selectedLead["First Name"]} ({selectedLead.Phone})
            </h3>

            <div
              ref={chatRef}
              className="flex-1 overflow-y-auto border rounded p-3 bg-gray-50 space-y-2"
            >
              {selectedLead.interactionHistory.map((msg, idx) => {
                const isSystem = msg.type === "system";
                const isSent = msg.type === "outbound" || msg.type === "ai";
                const isReceived = msg.type === "inbound";
                const showBooking = bookingForMessageIndex === idx;

                const containerAlign = isSystem
                  ? "items-center"
                  : isSent
                  ? "items-end"
                  : "items-start";

                const bubbleClasses = isSystem
                  ? "bg-gray-300 text-xs text-black text-center self-center"
                  : isSent
                  ? "bg-green-500 text-white self-end"
                  : "bg-white text-black self-start";

                return (
                  <div key={idx} className={`flex flex-col gap-1 ${containerAlign}`}>
                    <div className={`p-2 rounded-2xl max-w-[75%] ${bubbleClasses}`}>
                      <p className="text-sm whitespace-pre-line">{msg.text}</p>
                      <p className="text-[10px] mt-1 text-right">{formatStamp(msg.date)}</p>
                    </div>

                    {(isReceived || msg.type === "ai") && (
                      <>
                        <button
                          onClick={() => handleBookClick(idx)}
                          className={`text-xs underline ml-2 ${
                            isReceived ? "self-start text-blue-600" : "self-end text-blue-100"
                          }`}
                        >
                          📅 Book
                        </button>

                        {showBooking && (
                          <div className={`flex flex-col gap-2 mt-1 ${isReceived ? "ml-2" : "mr-2"}`}>
                            <input
                              type="datetime-local"
                              value={bookingTime}
                              onChange={(e) => setBookingTime(e.target.value)}
                              className="text-sm border rounded px-2 py-1"
                            />
                            <button
                              onClick={handleConfirmBooking}
                              className="bg-green-600 text-white text-xs px-3 py-1 rounded w-fit"
                            >
                              Confirm Booking
                            </button>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                );
              })}
            </div>

            <textarea
              className="border rounded mt-3 p-2 h-24 resize-none"
              placeholder="Type your message..."
              value={reply}
              onChange={(e) => setReply(e.target.value)}
            />
            <button
              onClick={handleReply}
              className="mt-2 self-end bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded"
            >
              Send Reply
            </button>
          </>
        ) : (
          <p>Select a conversation to view messages.</p>
        )}
      </div>
    </div>
  );
}
