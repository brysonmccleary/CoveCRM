export default function ReferralPanel() {
  return (
    <div className="p-6 text-gray-500 text-sm">
      Referral tracking and commissions coming soon.
    </div>
  );
}
