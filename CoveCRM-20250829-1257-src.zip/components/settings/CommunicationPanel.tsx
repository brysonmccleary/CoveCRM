export default function CommunicationPanel() {
  return (
    <div className="p-6 text-gray-500 text-sm">
      Booking and communication settings coming soon.
    </div>
  );
}
