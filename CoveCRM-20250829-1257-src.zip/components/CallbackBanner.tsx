export default function CallbackBanner() {
  return null;
}
