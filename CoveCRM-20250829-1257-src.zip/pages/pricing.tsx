export default function PricingPage() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Pricing</h1>
      <p>This page will show your billing or plan tiers.</p>
    </div>
  );
}
