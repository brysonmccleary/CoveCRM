declare module "parse-address" {
  const parseAddress: any;
  export default parseAddress;
}
